package com.kacu.planerplus;

public class UsersProfileItem {
    private String imageResource;
    private String text1;



    public UsersProfileItem(String imageResource, String text1) {
        this.imageResource = imageResource;
        this.text1 = text1;
    }

    public String getImageResource() {
        return imageResource;
    }

    public String getText1() {
        return text1;
    }


}
